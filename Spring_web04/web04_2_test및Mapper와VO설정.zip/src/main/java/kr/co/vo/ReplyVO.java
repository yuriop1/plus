package kr.co.vo;
//reply 테이블을 보고 작성
public class ReplyVO {
	//필드 설정
	
	//생성자, getter/setter/toString 소스 코드
}
