package kr.co.vo;

//게시판 및 댓글의 페이징 처리를 위한 조건을 저장하는 VO 클래스
public class Criteria {
	private int page;
	private int perPage;
	private int rowStart;
	private int rowEnd;
	
	//생성자, Getter, Setter, toString() 소스 작성
}
