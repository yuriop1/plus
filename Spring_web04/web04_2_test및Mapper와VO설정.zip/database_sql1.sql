-- MP_BOARD에 대한 시퀀스
CREATE SEQUENCE MP_BOARD_SEQ
START WITH 1
INCREMENT BY 1;

-- MP_REPLY에 대한 시퀀스
create sequence mp_reply_seq 
START WITH 1 
MINVALUE 0;

-- MP_FILE에 대한 시퀀스
CREATE SEQUENCE SEQ_MP_FILE_NO
START WITH 1 
INCREMENT BY 1 
NOMAXVALUE NOCACHE;

-- 댓글 테이블(MP_REPLY)의 BNO에 MP_BOARD의 BNO를 외래키로 추가
alter table mp_reply add constraint mp_reply_bno foreign key(bno)
references mp_board(bno);

-- 기본키를 두 개 이상의 컬럼으로 설정하는 경우
-- create table 테이블명(
-- 	....,
-- 	constriant 기본키제약조건컬럼명 primary key(컬럼명1, 컬럼명2)
-- )

-- 외래키에 의한 참조테이블이 있는 경우 무왜 연쇄 삭제
-- drop table 테이블명 cascade constraints;

-- SQL Deveploper에서 Relationship ERD 제작
-- 1) [파일]-[Data Modeler]-[임포트]-[데이터 딕셔너리]
-- 2) 데이터베이스에 접속에서 해당 접속이름 선택 후 [다음] 버튼
-- 3) 스키마/데이터베이스 선택에서 해당 데이터베이스(계정)을 선택 후 [다음] 버튼
-- 4) 임포트할 객체(테이블 또는 뷰) 선택 후 [다음] 버튼
-- 5) 디자인 생성 화면에서 [완료] 버튼
-- 6) 모델 비교 화면에서 [병합] 버튼 (두 번째 만들때만 해당)
-- 7) [파일]-[Data Modeler]-[다이어그램 인쇄]-[이미지 파일에]를 선택 후 이미지파일 저장위치와 이름을 입력 후 출력